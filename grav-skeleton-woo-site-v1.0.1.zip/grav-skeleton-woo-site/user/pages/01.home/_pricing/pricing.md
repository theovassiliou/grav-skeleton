---
columns: 
  - title: Starter
    price1: Free
    price2: per month
    icon: cog
    features:
      - name: 1GB Storage
      - name: 5GB Bandwidth
      - name: 2 Domains
      - name: 3 Databases
      - name: 1 FTP Account
      - name: 25 Email Accounts
    buttons:
      - text: Sign Up
        url: "#" 
  - title: Standard
    price1: $9.99
    price2: per month
    icon: thumbs-up
    features:
      - name: 3GB Storage
      - name: 10GB Bandwidth
      - name: 3 Domains
      - name: 5 Databases
      - name: 3 FTP Account
      - name: 30 Email Accounts
    buttons:
      - text: Sign Up
        url: "#"
  - title: Premium
    price1: $19.99
    price2: per month
    icon: star
    features:
      - name: 10GB Storage
      - name: 25GB Bandwidth
      - name: 5 Domains
      - name: 10 Databases
      - name: 10 FTP Account
      - name: 50 Email Accounts
    buttons:
      - text: Sign Up
        url: "#" 
  - title: Ultimate
    price1: $29.99
    price2: per month
    icon: trophy
    features:
      - name: 30GB Storage
      - name: Unlimited Bandwidth
      - name: 10 Domains
      - name: 15 Databases
      - name: 10 FTP Account
      - name: 50 Email Accounts
    buttons:
      - text: Sign Up
        url: "#"               
---
#Pricing Tables.
Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione
voluptatem sequi nesciunt.